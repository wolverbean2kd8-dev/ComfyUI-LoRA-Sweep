# ComfyUI LoRA Sweep v2.4 Beta — Face + Voice Checkpoint Comparison

**v2.4 adds local speaker-similarity ranking to the working v2.3 app** while retaining its face-ranking, comparison gallery, loader confirmation, and completion sound / Nerd Alert.

## Important: keep your existing results!

**Back up your current `lora_sweep.py`, then replace only that file in the SAME folder where v2.3 is installed. Do not delete or replace your `sweeps` folder.** The app looks for `sweeps` beside `lora_sweep.py` by default. If you launch v2.4 in a new folder, old runs will not appear unless you copy the complete old `sweeps` folder or use `--out` to point to its existing path.

## Installation (Windows)

ComfyUI must be running. Use the Python interpreter with which you run LoRA Sweep (not necessarily your ComfyUI embedded Python).

1. Close the current sweep app, back up the original `lora_sweep.py`.
2. Copy v2.4 `lora_sweep.py` into your existing LoRA Sweep directory (keep `sweeps/`).
3. Optional voice-scoring dependency:

   ```bat
   python -m pip install resemblyzer
   ```

   It uses PyTorch under the hood, usually CPU by default, and may need model weights on first use. Leave your existing ComfyUI environment alone. The voice feature is optional; if it cannot load its package, face scoring and generation still work.

4. **FFmpeg** must be available on PATH for MP4/MP3 audio extraction. Check with `ffmpeg -version` in CMD.
5. Start with `Launch_V2.bat` (or `python lora_sweep.py`), then open `http://127.0.0.1:8899`.

To use a separate application folder while keeping prior results:

```bat
python lora_sweep.py --out "C:\\Users\\YOURNAME\\Desktop\\LoRA_Sweep_v2\\sweeps"
```

## How to score the voice of each epoch

1. Upload a **clean voice reference** under **5. Voice similarity**. Formats: WAV, MP3, FLAC, M4A, OGG, max 20 MB each; ideally **5–30 seconds of one person speaking** without music, other voices, or strong noise.
2. Select the uploaded reference checkbox.
3. Run a sweep with **spoken dialogue** (not a silent 3-second visual test). Use the same prompt, seed, and dialogue for each epoch; 8–15-second speaking samples tend to be more useful.
4. For new runs with a selected voice reference, the app will try scoring automatically after the videos finish. For existing completed runs, select the run and click **Score voices**.
5. The new **Voice similarity ranking** appears below the face ranking. Each video also gets its own voice score or a reason it could not be scored.

The app extracts each MP4's audio, converts it to mono 16kHz WAV with FFmpeg, and calculates a speaker embedding using **Resemblyzer**. Higher cosine similarity means a closer match according to that model, **not a percentage** or proof of identity. Results may be distorted by background music, effects, very short speech, multiple speakers, pitch changes, or low-quality audio. It does **not** verify that the correct words were spoken or that lip-sync is accurate. Keep the face and voice scores independent and confirm by listening.

## Retained features

- ComfyUI API-format workflow loading and automated LoRA epoch swapping
- Confirmation of selected LoRA loader before queueing (important when multiple loaders exist)
- Consistent prompt/seed and optional strength override
- Responsive video gallery, playback, manual ratings
- Optional reference-face scoring (InsightFace + ONNX Runtime + OpenCV + NumPy)
- Saved runs in `sweeps/` and voice samples in `sweeps/voice_references/`
- Completion chime, optional spoken **“Your LoRA epochs are done, you nerd!”**, or silent mode

## Troubleshooting

- **Old runs disappeared:** The new script is in a different folder. Start it from the old folder or pass `--out` to your existing `sweeps` directory. **Do not regenerate the videos** merely because the gallery is empty.
- **Voice scoring unavailable:** Run `python -c "from resemblyzer import VoiceEncoder; print('OK')"` in the environment launching the script. See the scoring error shown in the web UI.
- **FFmpeg not found:** Add FFmpeg to PATH and restart CMD.
- **No usable speech:** Use longer speaking footage and a clean reference; silent clips do not have a valid voice similarity score.
- **Incorrect speaker in MP4:** Audio from interviews with multiple speakers is *not isolated automatically*. Use single-person clips; voice scores can be misleading otherwise.
- **Correct LoRA swapped?** Confirm the loader after importing any new API workflow. The app swaps only the selected `lora_name` input.

**Beta note:** Tested for Python syntax, JavaScript syntax, HTTP startup and upload routes. The actual Resemblyzer model evaluation has not been tested on your local Windows environment yet. Your existing v2.3 should remain backed up.
